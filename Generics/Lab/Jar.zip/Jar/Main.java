

public class Main {
    public static void main(String[] args) {
//        Jar<String> stringJar = new Jar<>();
//        stringJar.add("Pako");
//        stringJar.add("Ruro");
//        String removed = stringJar.remove();
//        System.out.println(removed);
//
//        Jar<Integer> integerJar = new Jar<>();
//        integerJar.add(5);
//        integerJar.add(7);
//        int removedNumber = integerJar.remove();
//        System.out.println(removedNumber);
    }
}
